package by.epam.unit02.main;

public class Task01 {

    public static void main (String[] args) {

        int a = 10;
        int b = 20;
        int c = 30;
        int z = 0;

        z = (a - 3) * b / 2 + c;

        System.out.println("Значение функции z = " + z);
    }
}
